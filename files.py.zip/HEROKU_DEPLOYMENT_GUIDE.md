# Deploy Your Resume Analyzer to Heroku 🚀

## What You'll Get:
- Live backend running 24/7
- Free tier available (500 hours/month = ~20 days always-on)
- Public URL like: `https://your-app-name.herokuapp.com`
- Anyone can access it from anywhere

---

## Step 1: Download 3 Files & Add to Your Project

You now have 3 new files to download:
1. `requirements.txt`
2. `Procfile`
3. `runtime.txt`

**Download all 3 and save them in your `career_fit` folder** (same folder as `app.py`)

Your folder should look like:
```
career_fit/
├── app.py
├── advisor.py
├── skill_extractor.py
├── requirements.txt       ← NEW
├── Procfile              ← NEW
├── runtime.txt           ← NEW
└── ... other files
```

---

## Step 2: Set Up Heroku Account (Free)

1. Go to: https://www.heroku.com/
2. Click "Sign Up" (top right)
3. Fill in: Email, Password, Company (leave blank), Role (Student works)
4. Click "Create Free Account"
5. Check your email and verify account
6. You're done! ✅

---

## Step 3: Install Heroku CLI

Download and install: https://devcenter.heroku.com/articles/heroku-cli

**On Windows:**
- Go to the link above
- Click "Download for Windows"
- Run the installer
- Restart your terminal

**Verify installation:**
```bash
heroku --version
```

You should see a version number.

---

## Step 4: Login to Heroku

In your terminal, run:
```bash
heroku login
```

It will open a browser. Click "Log In" → Enter your credentials.

Go back to terminal - you should see:
```
Logged in as your-email@example.com
```

---

## Step 5: Create Heroku App

In your terminal (in the `career_fit` folder), run:

```bash
heroku create your-app-name
```

Replace `your-app-name` with something unique, like:
- `career-fit-analyzer`
- `resume-analyzer-123`
- `job-fit-checker`

**Important:** It must be unique (no one else can have that name).

You should see:
```
Creating ⬢ your-app-name... done
https://your-app-name.herokuapp.com/ | https://git.heroku.com/your-app-name.git
```

Copy the URL: `https://your-app-name.herokuapp.com/`

---

## Step 6: Deploy Your Code

**Initialize Git (if not already done):**

```bash
git init
```

**Add files:**
```bash
git add .
```

**Commit:**
```bash
git commit -m "Initial commit"
```

**Deploy to Heroku:**
```bash
git push heroku main
```

If you get error about "main" branch, try:
```bash
git push heroku master
```

**Wait for deployment to finish** (1-2 minutes). You should see:
```
Waiting for release.... done
https://your-app-name.herokuapp.com/ deployed to Heroku
```

---

## Step 7: Update Frontend URL

Your HTML frontend needs to know the new backend URL.

1. Download `resume_analyzer.html` again
2. Open it in a text editor
3. Find this line (around line 280):
   ```javascript
   const API_URL = "http://localhost:8000";
   ```
4. Change it to:
   ```javascript
   const API_URL = "https://your-app-name.herokuapp.com";
   ```
5. Save the file
6. Open it in your browser - it should work! ✅

---

## Step 8: Test Your Live App!

1. Open: `https://your-app-name.herokuapp.com/health`
2. You should see: `{"health":"healthy"}`
3. Open your HTML file
4. Upload a resume
5. Analyze! 🎉

---

## You Now Have:

✅ **Backend running on:** `https://your-app-name.herokuapp.com`
✅ **Frontend:** Your HTML file (works anywhere)
✅ **Anyone can use it:** Just share the HTML file or the Heroku URL

---

## Share Your App:

- **HTML File:** Share the `resume_analyzer.html` file with anyone
- **Backend URL:** Anyone with the HTML file + your Heroku URL can use it
- **Live Demo:** Create a simple website linking to the app

---

## Troubleshooting:

**"Git is not installed"**
→ Download from: https://git-scm.com/

**"App didn't deploy"**
→ Run: `heroku logs --tail`
→ This shows you the error

**"Heroku CLI not found"**
→ Restart your computer after installing Heroku CLI

**"Port error"**
→ Heroku uses different ports - the Procfile handles this ✓

---

## Next Steps (Optional):

1. Add a custom domain (costs $)
2. Add database for storing results
3. Add user authentication
4. Deploy frontend to Vercel (makes it faster)

---

## You're Deploying a Real App! 🚀

This is production-ready code. Congratulations! 🎉
